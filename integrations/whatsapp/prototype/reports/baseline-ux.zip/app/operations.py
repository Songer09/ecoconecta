from fastapi import HTTPException
from datetime import datetime, timezone
from app.db import one, query, rows, audit
from app.knowledge import BOGOTA


def history(db, rid, status, actor):
    query(
        db,
        "INSERT INTO request_status_history(request_id,status,actor) VALUES(:r,:s,:a)",
        r=rid,
        s=status,
        a=actor,
    )
    audit(db, actor, status, rid)


def notify(db, user, kind, body):
    query(
        db,
        "INSERT INTO notifications(user_id,kind,body) VALUES(:u,:k,:b)",
        u=user,
        k=kind,
        b=body,
    )


def create(db, user, draft):
    ids = []
    for item in draft["items"]:
        mat = one(
            db,
            "SELECT flow FROM materials WHERE name=:name AND accepted FOR SHARE",
            name=item["material"],
        )
        if not mat:
            raise HTTPException(
                409, "La aceptación del material cambió. Consulta coordinación."
            )
        rid = one(
            db,
            """INSERT INTO collection_requests(owner_id,material,flow,quantity,unit,address,generator,preference)
          VALUES(:owner,:material,:flow,:quantity,:unit,:address,:generator,:preference) RETURNING id""",
            owner=user,
            flow=mat["flow"],
            **item,
            **{k: draft[k] for k in ("address", "generator", "preference")},
        )["id"]
        history(db, rid, "recibida", user)
        query(
            db,
            "INSERT INTO alerts(request_id,flow,kind,user_id) VALUES(:r,:f,'nuevo aviso',:u)",
            r=rid,
            f=mat["flow"],
            u=user,
        )
        for coord in rows(
            db,
            "SELECT id FROM users WHERE active AND role='coordinator' AND flow=:f",
            f=mat["flow"],
        ):
            notify(
                db,
                coord["id"],
                "alert",
                f"Nuevo aviso ECO-{rid}. Consulta la bandeja de tu colectivo.",
            )
        ids.append("ECO-" + str(rid))
    return ", ".join(ids)


def visible(db, rid, actor, lock=False):
    sql = """SELECT r.*,a.collector_id,a.coordinator_id,s.scheduled_at FROM collection_requests r
        LEFT JOIN assignments a ON r.id=a.request_id LEFT JOIN schedules s ON r.id=s.request_id
        WHERE r.id=:rid AND (:role='admin' OR (r.owner_id=:uid AND :role='resident')
        OR (r.flow=:flow AND :role='coordinator') OR (a.collector_id=:uid AND :role='collector'))"""
    row = one(
        db,
        sql + (" FOR UPDATE OF r" if lock else ""),
        rid=rid,
        role=actor["role"],
        uid=actor["id"],
        flow=actor["flow"],
    )
    if not row:
        raise HTTPException(404, "Solicitud no disponible")
    return row


def transition(db, rid, actor, action, data):
    row = visible(db, rid, actor, True)
    uid = actor["id"]
    if action in ("assign", "schedule") and actor["role"] != "coordinator":
        raise HTTPException(403, "Se requiere coordinación del colectivo")
    if action == "assign":
        collector = one(
            db,
            "SELECT id FROM users WHERE id=:id AND active AND role='collector' AND flow=:f FOR SHARE",
            id=data.collector_id,
            f=row["flow"],
        )
        if row["status"] != "recibida" or not collector:
            raise HTTPException(409, "Verifica el estado y el recolector del colectivo")
        query(
            db,
            "INSERT INTO assignments VALUES(:r,:u,:c)",
            r=rid,
            u=uid,
            c=data.collector_id,
        )
        status = "asignada"
    elif action == "schedule":
        if row["status"] != "asignada" or data.scheduled_at <= datetime.now(
            timezone.utc
        ):
            raise HTTPException(409, "Se requiere asignación y una fecha futura")
        query(
            db,
            "INSERT INTO schedules VALUES(:r,:t,:u)",
            r=rid,
            t=data.scheduled_at,
            u=uid,
        )
        handle = one(
            db, "SELECT handle FROM users WHERE id=:id", id=row["collector_id"]
        )["handle"]
        notify(
            db,
            row["owner_id"],
            "schedule",
            f"ECO-{rid} programada para {data.scheduled_at.astimezone(BOGOTA):%d/%m/%Y %H:%M}. Responsable: {handle}.",
        )
        status = "programada"
    elif action == "collect":
        if actor["role"] != "collector" or row["collector_id"] != uid:
            raise HTTPException(403, "Se requiere el recolector asignado")
        if row["status"] == "recolectada":
            event = one(
                db,
                "SELECT quantity,unit FROM collection_events WHERE request_id=:r",
                r=rid,
            )
            if event["quantity"] != data.quantity or event["unit"] != data.unit:
                raise HTTPException(
                    409, "El cierre existente tiene otra cantidad o unidad"
                )
            return {"status": "recolectada"}
        if row["status"] != "programada":
            raise HTTPException(409, "Falta la programación")
        query(
            db,
            "INSERT INTO collection_events(request_id,actor,quantity,unit) VALUES(:r,:u,:q,:unit)",
            r=rid,
            u=uid,
            q=data.quantity,
            unit=data.unit,
        )
        query(
            db,
            """INSERT INTO points_ledger(request_id,rule_id,points)
            SELECT :r,id,rate*:q FROM points_rules WHERE material=:m AND unit=:unit
            AND starts_at<=now() AND (ends_at IS NULL OR ends_at>now()) ORDER BY starts_at DESC,id DESC LIMIT 1""",
            r=rid,
            q=data.quantity,
            m=row["material"],
            unit=data.unit,
        )
        status = "recolectada"
    else:
        raise ValueError("Acción desconocida")
    query(db, "UPDATE collection_requests SET status=:s WHERE id=:r", s=status, r=rid)
    history(db, rid, status, uid)
    return {"status": status}
