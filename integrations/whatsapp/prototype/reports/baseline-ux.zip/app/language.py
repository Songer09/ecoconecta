"""NLU local y contrato de interpretación. Los resultados nunca son comandos."""

import re
import unicodedata
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

Intent = Literal[
    "collection",
    "track",
    "event",
    "training",
    "recycling",
    "compost",
    "material",
    "points",
    "modify",
    "cancel",
    "human",
    "hello",
    "bye",
    "ambiguous",
    "offtopic",
]
Scope = Literal["IN_SCOPE", "OUT_OF_SCOPE", "UNCERTAIN"]


class Interpretation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scope: Scope
    intent: Intent
    material: str | None = Field(default=None, max_length=80)
    quantity: float | None = Field(default=None, gt=0, le=100000)
    unit: str | None = Field(default=None, max_length=20)
    date: str | None = Field(default=None, max_length=80)
    time: str | None = Field(default=None, max_length=80)
    generator: Literal["hogar", "unidad productiva"] | None = None
    topic: str = Field(default="", max_length=100)


def norm(s):
    return "".join(
        c
        for c in unicodedata.normalize("NFD", s.lower())
        if not unicodedata.combining(c)
    ).strip()


ALIASES = {
    "cartón": r"carton(?:es)?|cajas? de carton",
    "papel": r"papel(?:es)?",
    "botellas PET": r"pet|botellas? (?:plasticas?|de plastico)",
    "latas": r"latas?|aluminio",
    "vidrio": r"vidrios?",
    "cáscaras": r"cascaras?|conchas de fruta",
    "restos vegetales": r"restos (?:vegetales|de (?:frutas?|verduras?))|residuos organicos|organicos",
    "hojas": r"hojas?|poda",
    "café": r"borra|posos de cafe|cafe molido",
}
SPECIAL = r"\b(pilas?|baterias?|medicamentos?|aceites?|panales?|sanitari[oa]s?|electronicos?|jeringas?|vidrio roto|icopor|contaminad[oa]s?|suci[oa]s?|mojad[oa]s?|humed[oa]s?|servilletas?|carne|huesos?|lacteos?|quimicos?|pintura|grasient[oa]s?|grasos?[oa]?|grasa|pizza)\b"
UNSAFE = r"(ignora|olvida|omite|desobedece).{0,35}(instrucciones|reglas|prompt)|actua como|revela.{0,20}(clave|prompt|token)|system prompt"
OTHER = r"\b(mundial|futbol|partido de futbol|bitcoin|criptomoneda|python|javascript|pelicula|presidente|celular|horoscopo|programacion de software|receta de cocina)\b"
NUM = {
    "un": 1,
    "una": 1,
    "uno": 1,
    "dos": 2,
    "tres": 3,
    "cuatro": 4,
    "cinco": 5,
    "seis": 6,
    "siete": 7,
    "ocho": 8,
    "nueve": 9,
    "diez": 10,
    "quince": 15,
    "veinte": 20,
}
UNITS = {
    "kg": "kg",
    "kilo": "kg",
    "kilogramo": "kg",
    "bolsa": "bolsas",
    "costal": "costales",
    "costale": "costales",
    "caneca": "canecas",
    "balde": "baldes",
    "unidad": "unidades",
    "unidade": "unidades",
    "botella": "unidades",
    "litro": "l",
}
AMOUNT = re.compile(
    r"(?<![-\d.,])\b(\d{1,6}(?:[.,]\d{1,3})?|"
    + "|".join(NUM)
    + r")\s+(kg|kilos?|kilogramos?|bolsas?|costal(?:es)?|canecas?|baldes?|unidades?|botellas?|litros?)\b"
)


def amount(s):
    found = AMOUNT.search(s)
    if not found:
        return {}
    value, unit = found.groups()
    n = NUM[value] if value in NUM else float(value.replace(",", "."))
    if 0 < n <= 100000:
        return {"quantity": n, "unit": UNITS[unit.rstrip("s")]}
    return {}


def materials(s):
    return [
        name
        for name, pattern in ALIASES.items()
        if re.search(r"\b(?:" + pattern + r")\b", s)
    ]


def classify(text):
    s = norm(text)
    mats = materials(s)

    def result(intent, scope="IN_SCOPE"):
        return Interpretation(
            intent=intent, scope=scope, material=mats[0] if mats else None, **amount(s)
        )

    if re.search(UNSAFE + "|" + OTHER, s):
        return result("offtopic", "OUT_OF_SCOPE")
    rules = [
        ("cancel", r"\b(cancelar?|anula\w*|desistir)\b"),
        (
            "modify",
            r"\b(corregir|modific\w*|cambiar|corrijo|perdon|en realidad|no son)\b",
        ),
        ("points", r"\bpuntos\b"),
        (
            "track",
            r"\b(estado|seguimiento|como va|ya pasaron|mis solicitudes|codigo eco)\b|eco-[0-9a-f]",
        ),
        ("training", r"\b(taller\w*|curso\w*|capacit\w*|ensen\w*|charla\w*)\b"),
        ("event", r"\b(evento\w*|actividad\w*|jornada\w*|agenda)\b"),
        ("human", r"\b(humano|asesor|persona real|hablar con coordinacion)\b"),
        (
            "collection",
            r"\b(tengo|reuni|necesito que|vengan|pueden (?:venir|recoger|pasar)|quiero (?:entregar|avisar|solicitar)|ya junte|pasen por)\b",
        ),
        ("compost", r"\b(compost\w*|huerta|abono|biodegradable)\b"),
        ("recycling", r"\b(recicl\w*|separ\w*|aprovech\w*)\b"),
    ]
    for intent, pattern in rules:
        if re.search(pattern, s):
            if intent == "collection" and (
                re.search(
                    r"\b(si tengo|hipoteticamente|que hago|como (separo|reciclo)|puedo reciclar)\b",
                    s,
                )
                or not (
                    mats
                    or re.search(
                        SPECIAL
                        + r"|residu|basura|recoge|recolec|recicla|huerta|pasen|botellas?",
                        s,
                    )
                )
            ):
                continue
            return result(intent)
    if mats or re.search(SPECIAL, s):
        return result("collection" if amount(s) and "?" not in s else "material")
    if re.fullmatch(r"(hola|buenas|buenos dias|buenas tardes|buenas noches)[!. ]*", s):
        return result("hello")
    if re.fullmatch(r"(adios|hasta luego|chao|gracias)[!. ]*", s):
        return result("bye")
    if "?" in s or s.startswith(("quien ", "cuanto cuesta", "escribe ")):
        return result("offtopic", "OUT_OF_SCOPE")
    return result("ambiguous", "UNCERTAIN")


def private_text(s):
    return bool(
        re.search(
            r"@|\d{6,}|\b(calle|carrera|cra|manzana|direccion|me llamo|mi nombre|telefono|diagonal|transversal|avenida|barrio|vivo en|cedula|casa \d)\b",
            norm(s),
        )
    )
