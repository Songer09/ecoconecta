import json
import re
from app.db import query, one
from app.language import norm, materials, amount, SPECIAL, UNSAFE, OTHER
from app.providers import understand
from app.operations import create, history
from app.knowledge import agenda, education, BOGOTA

LIMIT = "Soy el asistente ambiental de EcoConecta. Puedo ayudarte con residuos, recolecciones y actividades de Villas de San Pablo."
CLARIFY = "¿Quieres avisar que tienes residuos, consultar tu solicitud o preguntar por un material?"
ID = re.compile(r"\b(?:eco-)?([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})\b", re.I)
ADDRESS = r"\b(?:manzana|mz|calle|carrera|cra|diagonal|transversal|avenida)\s+[^,;?!]{1,85}(?:,\s*(?:casa|local|lote|apto|apartamento)\s+[^,;?!]{1,30})?"
PREF = r"\b(?:pasado manana|manana|lunes|martes|miercoles|jueves|viernes|sabado|domingo|por la (?:tarde|noche|manana)|sin preferencia|cualquier horario|\d{1,2}/\d{1,2}(?:/\d{2,4})?|[012]?\d:[0-5]\d)\b[^,;?!]{0,55}"
YES = {"si", "confirmo", "si confirmo", "confirmar", "de acuerdo"}


def save(db, uid, draft):
    query(
        db,
        """INSERT INTO conversations VALUES(:u,CAST(:d AS jsonb))
      ON CONFLICT(user_id) DO UPDATE SET draft=EXCLUDED.draft""",
        u=uid,
        d=json.dumps(draft, ensure_ascii=False),
    )


def catalog(db, mat):
    return one(db, "SELECT flow FROM materials WHERE name=:m AND accepted", m=mat)


def review(db, uid):
    query(db, "INSERT INTO alerts(kind,user_id) VALUES('revisión humana',:u)", u=uid)
    return "Dejé un aviso para revisión humana. Coordinación debe verificar el material antes de solicitar una recolección."


def progress(db, uid, d):
    if not d.get("items"):
        d["waiting"] = "material"
        msg = "¿Qué material tienes listo?"
    else:
        for i, item in enumerate(d["items"]):
            if "quantity" not in item:
                d.update(waiting="amount", index=i)
                save(db, uid, d)
                return f"¿Qué cantidad aproximada de {item['material']} tienes y en qué unidad?"
        prompts = {
            "generator": "¿La entrega es de un hogar o de una unidad productiva?",
            "address": "¿Cuál es la dirección o referencia de recogida?",
            "preference": "¿Qué día o franja prefieres? También puedes decir «sin preferencia».",
        }
        key = next((k for k in prompts if not d.get(k)), None)
        if key:
            d["waiting"] = key
            msg = prompts[key]
        else:
            d["waiting"] = "confirm"
            parts = [
                f"{i['quantity']:g} {i['unit']} de {i['material']}" for i in d["items"]
            ]
            msg = f"{'; '.join(parts)}. {d['generator']}, {d['address']}. Preferencia: {d['preference']}. "
            if len(parts) > 1:
                msg += "Registraré avisos separados. "
            msg += "¿Confirmas el aviso a coordinación? La visita queda pendiente de programación."
    save(db, uid, d)
    return msg


def slots(db, uid, d, text, result=None):
    s = norm(text)
    if re.search(SPECIAL, s):
        save(db, uid, {})
        return review(db, uid)
    waiting = d.get("waiting")
    mats = materials(s)
    if result and result.material and not mats and norm(result.material) in s:
        mats = [result.material]
    if not mats and waiting == "material" and re.fullmatch(r"[a-z][a-z0-9 ]{2,75}", s):
        save(db, uid, {})
        return review(db, uid)
    if mats:
        if any(not catalog(db, m) for m in mats):
            save(db, uid, {})
            return review(db, uid)
        old = {i["material"]: i for i in d.get("items", [])}
        # A replacement at confirmation invalidates the old summary.
        if len(mats) == 1 and len(old) > 1 and mats[0] in old:
            targets = [old[mats[0]]]
        else:
            d["items"] = [old.get(m, {"material": m}) for m in mats]
            targets = d["items"]
        chunks = re.split(r"\s+y\s+|[,;](?!\d)", s)
        for item in targets:
            chunk = next(
                (
                    c
                    for c in chunks
                    if item["material"] in materials(c) and len(materials(c)) == 1
                ),
                None,
            )
            if chunk:
                item.update(amount(chunk))
    elif (
        amount(s)
        and d.get("items")
        and (waiting == "amount" or (result and result.intent == "modify"))
    ):
        if len(d["items"]) > 1 and waiting != "amount":
            return "¿De cuál material quieres corregir la cantidad?"
        d["items"][d.get("index", 0)].update(amount(s))
    elif (
        waiting == "amount"
        and re.fullmatch(r"(?:unas? |unos? )?(\d{1,5})", s)
        and d["items"][d["index"]]["material"] in ("botellas PET", "latas")
    ):
        n = int(s.split()[-1])
        if n > 0:
            d["items"][d["index"]].update(quantity=n, unit="unidades")
    if re.search(r"\b(negocio|tienda|unidad productiva|restaurante|empresa)\b", s):
        d["generator"] = "unidad productiva"
    elif re.search(r"\b(hogar|mi casa)\b", s) or s == "casa":
        d["generator"] = "hogar"
    pref = re.search(PREF, s)
    verified_preference = (
        " ".join(
            value for value in (result.date, result.time) if value and norm(value) in s
        )
        if result
        else ""
    )
    addr = re.search(ADDRESS, s)
    if addr:
        d["address"] = text[
            addr.start() : min(
                addr.end(),
                pref.start() if pref and pref.start() > addr.start() else addr.end(),
            )
        ].strip(" ,.")
    elif (
        waiting == "address"
        and 3 <= len(text) <= 160
        and not pref
        and not mats
        and "?" not in s
    ):
        d["address"] = text.strip()
    if pref:
        d["preference"] = text[pref.start() : pref.end()].strip(" ,.")
    elif verified_preference:
        d["preference"] = verified_preference
    elif waiting == "preference" and re.fullmatch(r"(?:[01]?\d|2[0-3]):[0-5]\d", s):
        d["preference"] = text.strip()
    return progress(db, uid, d)


def owned(db, uid, text):
    match = ID.search(text)
    return (
        one(
            db,
            """SELECT r.*,s.scheduled_at,u.handle AS collector FROM collection_requests r
       LEFT JOIN schedules s ON s.request_id=r.id LEFT JOIN assignments a ON a.request_id=r.id
       LEFT JOIN users u ON u.id=a.collector_id WHERE owner_id=:u
       AND (CAST(:id AS uuid) IS NULL OR r.id=CAST(:id AS uuid)) ORDER BY created_at DESC,r.id LIMIT 1 FOR UPDATE OF r""",
            u=uid,
            id=match.group(1) if match else None,
        )
        if match or "eco-" not in norm(text)
        else None
    )


def handle(db, uid, text):
    # Serializes a resident's draft, confirmation and opt-in changes.
    one(db, "SELECT id FROM users WHERE id=:u AND active FOR UPDATE", u=uid)
    s = norm(text).strip(" ¡!.")
    current = one(db, "SELECT draft FROM conversations WHERE user_id=:u", u=uid)
    d = current["draft"] if current else {}
    if s in ("acepto audio", "revoco audio"):
        query(
            db,
            """INSERT INTO consents VALUES(:u,:v,now()) ON CONFLICT(user_id) DO UPDATE SET audio=:v,changed_at=now()""",
            u=uid,
            v=s == "acepto audio",
        )
        return "Permiso de voz actualizado. Puedes revocarlo con REVOCO AUDIO."
    if s in YES and d.get("waiting") == "confirm":
        if any(not catalog(db, i["material"]) for i in d["items"]):
            save(db, uid, {})
            return review(db, uid)
        if d.get("edit"):
            rid = d["edit"]
            r = owned(db, uid, rid)
            if not r or r["status"] != "recibida":
                save(db, uid, {})
                return (
                    "La solicitud ya está en gestión. Pide contacto con coordinación."
                )
            i = d["items"][0]
            query(
                db,
                "UPDATE collection_requests SET quantity=:q,unit=:unit,preference=:p,address=:a WHERE id=:r",
                r=rid,
                q=i["quantity"],
                unit=i["unit"],
                p=d["preference"],
                a=d["address"],
            )
            history(db, rid, "corregida", uid)
            save(db, uid, {})
            return f"Aviso ECO-{rid} actualizado."
        ids = create(db, uid, d)
        save(db, uid, {})
        return f"Aviso recibido: {ids}. Coordinación revisará la solicitud. Aún no hay visita programada."
    if s in YES and d.get("waiting") == "cancel":
        r = owned(db, uid, d["id"])
        save(db, uid, {})
        if r and r["status"] in ("recibida", "asignada"):
            query(
                db,
                "UPDATE collection_requests SET status='cancelada' WHERE id=:id",
                id=r["id"],
            )
            history(db, r["id"], "cancelada", uid)
            return "Solicitud cancelada."
        return "El estado ya cambió. Solicita contacto con coordinación."
    if s == "no" and d:
        save(db, uid, {})
        return "Descarté el cambio pendiente."
    if re.search(UNSAFE + "|" + OTHER, s):
        return LIMIT
    if d and s in YES:
        return progress(db, uid, d)
    result = understand(text, local_only=bool(d) or bool(ID.search(text)))
    intent = result.intent
    if result.scope == "OUT_OF_SCOPE":
        return LIMIT
    if result.scope == "UNCERTAIN" and not d:
        return CLARIFY
    if intent in (
        "event",
        "training",
        "points",
        "track",
        "recycling",
        "compost",
        "material",
        "human",
        "hello",
        "bye",
    ) and not (
        d
        and intent in ("material", "compost", "recycling")
        and not re.search(r"[?¿]|\b(como|sirve|puedo|antes|que hago)\b", s)
    ):
        if intent in ("training", "event"):
            reply = agenda(db, intent, text)
        elif intent == "points":
            val = one(
                db,
                "SELECT coalesce(sum(points),0) AS n FROM points_ledger JOIN collection_requests r ON r.id=request_id WHERE r.owner_id=:u",
                u=uid,
            )
            reply = f"Tienes {val['n']:g} puntos acreditados."
        elif intent == "track":
            r = owned(db, uid, text)
            reply = (
                f"ECO-{r['id']}: {r['status']}."
                if r
                else "No encuentro esa solicitud entre las tuyas."
            )
            if r and r["scheduled_at"]:
                reply += f" Programación: {r['scheduled_at'].astimezone(BOGOTA):%d/%m/%Y %H:%M}, {r['collector']}."
        elif intent in ("recycling", "compost", "material"):
            reply = education(db, text, result.topic)
        elif intent == "human":
            reply = review(db, uid)
        else:
            reply = (
                "¡Hola! " + CLARIFY
                if intent == "hello"
                else "Gracias por participar en EcoConecta."
            )
        return reply + (" Tu borrador sigue pendiente." if d else "")
    if intent == "cancel":
        if d and not ID.search(text):
            save(db, uid, {})
            return "Descarté el borrador."
        r = owned(db, uid, text)
        if r and r["status"] in ("recibida", "asignada"):
            save(db, uid, {"waiting": "cancel", "id": str(r["id"])})
            return f"¿Confirmas cancelar ECO-{r['id']}?"
        return "No encuentro una solicitud propia disponible para cancelar."
    if intent == "modify" and not d:
        r = owned(db, uid, text)
        if not r or r["status"] != "recibida":
            return "Solo puedes corregir un aviso propio pendiente de revisión."
        d = {k: r[k] for k in ("preference", "address", "generator")}
        d.update(
            edit=str(r["id"]),
            items=[
                {
                    "material": r["material"],
                    "quantity": float(r["quantity"]),
                    "unit": r["unit"],
                }
            ],
            waiting="amount",
            index=0,
        )
        save(db, uid, d)
        if not amount(s):
            return "¿Cuál es la cantidad y unidad correctas?"
    if d.get("waiting") == "cancel":
        return "Responde sí para cancelar o no para conservar tu solicitud."
    if (
        d.get("edit")
        and materials(s)
        and set(materials(s)) != {d["items"][0]["material"]}
    ):
        return "Para cambiar de material, cancela el aviso y crea otro. Para salir de la corrección, responde no."
    if d or (intent == "collection" and result.scope == "IN_SCOPE"):
        return slots(db, uid, d, text, result)
    return CLARIFY if result.scope == "UNCERTAIN" or intent == "ambiguous" else LIMIT
