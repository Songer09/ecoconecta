import json
import re
from uuid import uuid4
from app.db import query, one
from app.language import norm, materials, SPECIAL, UNSAFE, OTHER
from app.entities import amount, correction, mentions
from app.analytics import record
from app.providers import understand
from app.operations import create, history, declared_items, store_item
from app.knowledge import agenda, education, BOGOTA

LIMIT = "Soy el asistente ambiental de EcoConecta. Puedo ayudarte con residuos, recolecciones y actividades de Villas de San Pablo."
CLARIFY = "¿Quieres avisar que tienes residuos, consultar tu solicitud o preguntar por un material?"
ID = re.compile(r"\b(?:eco-)?([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})\b", re.I)
ADDRESS = re.compile(
    r"\b(?:manzana|mz|calle|carrera|cra|diagonal|transversal|avenida|conjunto|bloque|lote|barrio|casa|local)"
    r"\s+(?:\d[\w# -]{0,45}|[a-z][\w -]{0,45})"
    r"(?:,\s*(?:casa|local|lote|apto|apartamento)\s+[\w# -]{1,30})?"
)
PREF = re.compile(
    r"\b(?:pasado manana|manana|lunes|martes|miercoles|jueves|viernes|sabado|domingo|"
    r"(?:por|en) la (?:tarde|noche|manana)|sin preferencia|cualquier horario|"
    r"\d{1,2}/\d{1,2}(?:/\d{2,4})?|[01]?\d:[0-5]\d|2[0-3]:[0-5]\d)\b"
    r"(?:\s+(?:(?:por|en|de) la (?:manana|tarde|noche)|a las \d{1,2}(?::\d{2})?))?"
)
CLARIFICATIONS = {
    "plástico": {"botellas PET", "botellas de plástico"},
    "residuos de cocina": {"cáscaras", "restos vegetales", "café", "hojas"},
}
AMBIGUOUS = set(CLARIFICATIONS)

YES = {"si", "confirmo", "si confirmo", "confirmar", "de acuerdo"}


def save(db, uid, draft):
    query(
        db,
        """INSERT INTO conversations VALUES(:u,CAST(:d AS jsonb))
      ON CONFLICT(user_id) DO UPDATE SET draft=EXCLUDED.draft""",
        u=uid,
        d=json.dumps(draft, ensure_ascii=False),
    )


def catalog(db, mat):
    return one(db, "SELECT flow FROM materials WHERE name=:m AND accepted", m=mat)


def review(db, uid, attempt=None):
    record(db, "escalated", attempt, reason="human_review")
    query(db, "INSERT INTO alerts(kind,user_id) VALUES('revisión humana',:u)", u=uid)
    return "Dejé un aviso para revisión humana. Coordinación debe verificar el material antes de solicitar una recolección."


def summary(item):
    name = item.get("label") or item["material"]
    if item.get("quantity") is not None:
        desc = item.get("description")
        size = re.search(r"\b(grandes?|pequenas?|llenas?|median[ao]s?)$", desc or "")
        quantity = f"{item['quantity']:g} {item['unit']}"
        if (
            item["unit"]
            in {
                "bolsas",
                "cajas",
                "botellas",
                "baldes",
                "canecas",
                "costales",
                "unidades",
            }
            and item["quantity"] == 1
        ):
            quantity = (
                quantity.rstrip("s")
                if item["unit"] not in {"costales", "unidades"}
                else "1 " + {"costales": "costal", "unidades": "unidad"}[item["unit"]]
            )
        if size:
            quantity += " " + size[0]
        return f"{'aprox. ' if item.get('approximate') else ''}{quantity} de {name}"
    return f"{name} ({item.get('description') or 'cantidad sin indicar'})"


def missing(db, uid, draft, fields, text):
    draft["waiting"] = "details"
    draft["last_asked"] = fields
    record(db, "missing_asked", draft.get("attempt"), fields=fields)
    save(db, uid, draft)
    return text


def progress(db, uid, d):
    if special := d.get("unresolved", {}).get("special"):
        extra = (
            " Puedes decir «solo los demás» para continuar con el material reconocido."
            if d.get("items")
            else ""
        )
        return missing(
            db,
            uid,
            d,
            ["eligibility"],
            f"{special.capitalize()} requiere revisión. ¿Quieres pedir revisión humana?{extra}",
        )
    if d.get("unresolved"):
        labels = ", ".join(d["unresolved"].values())
        suffix = (
            " Puedes decir «solo los demás» para continuar con los materiales reconocidos."
            if d.get("items")
            else ""
        )
        return missing(
            db,
            uid,
            d,
            ["material"],
            f"Me falta confirmar qué material es o si la ruta recibe: {labels}. ¿Me lo aclaras?{suffix}",
        )
    if not d.get("items"):
        return missing(
            db,
            uid,
            d,
            ["material"],
            "¿Qué material tienes listo? Puedes decir, por ejemplo, cartón o cáscaras.",
        )
    if not d.get("address"):
        if d.get("preference"):
            return missing(
                db,
                uid,
                d,
                ["address"],
                "¿En qué dirección o referencia están los residuos?",
            )
        return missing(
            db,
            uid,
            d,
            ["address", "preference"],
            "¿En qué dirección o referencia están los residuos? Si tienes una preferencia, dime también cuándo te queda bien.",
        )
    groups = {}
    for item in d["items"]:
        mat = catalog(db, item["material"])
        flow = mat["flow"] if mat else "pending"
        groups.setdefault(flow, []).append(summary(item))
    labels = {"organic": "Huerta", "recyclable": "Reciclaje", "pending": "Por revisar"}
    parts = [f"{labels[flow]} · {', '.join(items)}" for flow, items in groups.items()]
    where = f"Lugar: {d['address']}."
    when = f" Preferencia: {d['preference']}." if d.get("preference") else ""
    split = " Se enviará un aviso por colectivo." if len(groups) > 1 else ""
    d["waiting"] = "confirm"
    d.pop("last_asked", None)
    save(db, uid, d)
    return f"{' / '.join(parts)}. {where}{when}{split} ¿Confirmas el aviso? Coordinación te confirmará la visita."


def address_and_preference(d, text, s, result):
    pref = PREF.search(s)
    if pref:
        d["preference"] = text[pref.start() : pref.end()].strip(" ,.")
    elif result:
        verified = [
            value for value in (result.date, result.time) if value and norm(value) in s
        ]
        if verified:
            d["preference"] = " ".join(verified)
    address_start = ADDRESS.search(s)
    if address_start:
        start = address_start.start()
        end = address_start.end()
        if pref and start < pref.start():
            end = min(end, pref.start())
        candidate = text[start:end]
        candidate = re.split(
            r"\s+(?:y\s+)?(?:pueden|puedes|podrian|pasen|hay|tengo|tenemos|queda(?:ria)? bien|para recoger)\b",
            candidate,
            maxsplit=1,
            flags=re.IGNORECASE,
        )[0]
        if re.search(
            r"\d|^(?:calle|barrio|conjunto|carrera|avenida|diagonal|transversal)\b",
            norm(candidate),
        ):
            d["address"] = candidate.strip(" ,.")
    elif "address" in d.get("last_asked", []) or d.get("waiting") == "address":
        candidate = text[: pref.start()] if pref else text
        candidate = re.sub(r"(?:[, ]+|[.])(?:y|para)?\s*$", "", candidate).strip()
        # Plain references are accepted in the answer to a location question.
        if 3 <= len(candidate) <= 160 and re.search(
            r"\b(?:frente|junto|esquina|al lado|detras|porter[ií]a|entrada|parque|iglesia|tienda)\b|\d",
            candidate,
            re.I,
        ):
            if not materials(norm(candidate)) and not amount(norm(candidate)):
                d["address"] = candidate


def original_excerpt(text, normalized, excerpt):
    start = normalized.find(excerpt) if excerpt else -1
    return text[start : start + len(excerpt)] if start >= 0 else excerpt


def slots(db, uid, d, text, result):
    text = text.strip()
    s = norm(text)
    if not d.get("attempt") and not d.get("edit"):
        d["attempt"] = str(uuid4())
        record(db, "request_started", d["attempt"])
    local = {hit.name: hit for hit in mentions(s)}
    for hit in result.materials:
        evidence = norm(hit.evidence)
        if (
            hit.name not in local
            and hit.name not in AMBIGUOUS
            and re.search(r"\b" + re.escape(evidence) + r"\b", s)
        ):
            if not mentions(evidence) and catalog(db, hit.name):
                local[hit.name] = hit.model_copy(
                    update={
                        "quantity": None,
                        "unit": None,
                        "description": None,
                        "approximate": False,
                    }
                )
    old = {i["material"]: i for i in d.get("items", [])}
    unresolved = d.setdefault("unresolved", {})
    if (
        unresolved
        and s in {"solo los demas", "continua con los demas", "solo los reconocidos"}
        and old
    ):
        unresolved.clear()
        return progress(db, uid, d)
    peers = re.split(r"\s+(?:y|e|junto con)\s+", s)
    if local and len(peers) > 1:
        for peer in peers[1:]:
            if (
                mentions(peer)
                or re.search(SPECIAL, peer)
                or PREF.search(peer)
                or ADDRESS.search(peer)
                or amount(peer)
            ):
                continue
            candidate = re.split(r"\s+(?:en|para|desde)\s+", peer, maxsplit=1)[0].strip(
                " ,.!?"
            )
            if re.fullmatch(
                r"(?:tambien )?(?:(?:un|una|unos|unas|varios|varias) )?[a-z][a-z ]{2,38}",
                candidate,
            ):
                if not re.search(
                    r"\b(?:pued\w*|vengan|dispongo|tengo|de cada|recoger|gracias)\b",
                    candidate,
                ):
                    unresolved.setdefault("uncatalogued", candidate)
    special = re.search(SPECIAL, s)
    if special:
        chunks = re.split(r"\s+(?:y|e|junto con)\s+|[,;](?!\d)", s)
        flagged = {
            hit.name
            for chunk in chunks
            if re.search(SPECIAL, chunk)
            for hit in mentions(chunk)
        }
        unresolved["special"] = special[0]
        for name in flagged:
            local.pop(name, None)
            old.pop(name, None)
        if not old and not local:
            save(db, uid, {})
            return review(db, uid, d.get("attempt"))
    was_asking_material = "material" in d.get("last_asked", [])
    added = 0
    for name, hit in local.items():
        mat = catalog(db, name)
        if not mat or name in AMBIGUOUS:
            unresolved[name] = hit.evidence
            continue
        added += name not in old
        unresolved.pop(name, None)
        item = old.setdefault(name, {"material": name})
        if hit.evidence != norm(name):
            start = s.find(hit.evidence)
            item["label"] = (
                text[start : start + len(hit.evidence)] if start >= 0 else hit.evidence
            )
        if hit.quantity is not None or hit.description:
            item.update(
                quantity=hit.quantity,
                unit=hit.unit,
                approximate=hit.approximate,
                description=original_excerpt(text, s, hit.description),
            )
    if (
        added
        and was_asking_material
        and not special
        and not any(name in AMBIGUOUS or not catalog(db, name) for name in local)
    ):
        # A reply to the material clarification can supersede the unresolved label.
        # If several labels were pending, require an explicit acknowledgement first.
        if len(unresolved) <= 1 and "special" not in unresolved:
            unresolved.clear()
    for pending, alternatives in CLARIFICATIONS.items():
        if (
            was_asking_material
            and pending in unresolved
            and alternatives.intersection(local)
            and pending not in local
        ):
            if any(catalog(db, name) for name in alternatives.intersection(local)):
                unresolved.pop(pending, None)
    if local:
        record(db, "materials_identified", d.get("attempt"), count=len(local))
    if old and (not local or result.intent == "modify") and not special:
        target = next(iter(old.values())) if len(old) == 1 else None
        if len(local) == 1:
            target = old.get(next(iter(local)))
        candidate = (
            text
            if not local
            else re.sub(
                r"\b(?:"
                + "|".join(re.escape(hit.evidence) for hit in local.values())
                + r")\b",
                "",
                s,
            )
            .strip(" ,")
            .removeprefix("de ")
            .strip()
        )
        corrected = correction(norm(candidate), target or {})
        if corrected and not target:
            return missing(
                db,
                uid,
                d,
                ["quantity_target"],
                "¿De cuál material quieres indicar esa cantidad?",
            )
        if (
            corrected
            and target
            and not any(hit.quantity is not None for hit in local.values())
        ):
            corrected["description"] = original_excerpt(
                text, s, corrected.get("description")
            )
            target.update(corrected)
    d["items"] = list(old.values())
    if re.search(r"\b(negocio|tienda|unidad productiva|restaurante|empresa)\b", s):
        d["generator"] = "unidad productiva"
    elif re.search(r"\b(hogar|mi casa)\b", s):
        d["generator"] = "hogar"
    address_and_preference(d, text, s, result)
    return progress(db, uid, d)


def education_reply(db, text, result):
    named = materials(norm(text))
    if len(named) > 1:
        return "\n".join(
            f"{name.capitalize()}: {education(db, name)}" for name in named
        )
    return education(db, text, result.topic)


def owned(db, uid, text):
    match = ID.search(text)
    return (
        one(
            db,
            """SELECT r.*,s.scheduled_at,u.handle AS collector FROM collection_requests r
       LEFT JOIN schedules s ON s.request_id=r.id LEFT JOIN assignments a ON a.request_id=r.id
       LEFT JOIN users u ON u.id=a.collector_id WHERE owner_id=:u
       AND (CAST(:id AS uuid) IS NULL OR r.id=CAST(:id AS uuid)) ORDER BY created_at DESC,r.id LIMIT 1 FOR UPDATE OF r""",
            u=uid,
            id=match.group(1) if match else None,
        )
        if match or "eco-" not in norm(text)
        else None
    )


def _handle(db, uid, text):
    s = norm(text).strip(" ¡!.")
    current = one(db, "SELECT draft FROM conversations WHERE user_id=:u", u=uid)
    d = current["draft"] if current else {}
    if s in ("acepto audio", "revoco audio"):
        query(
            db,
            """INSERT INTO consents VALUES(:u,:v,now()) ON CONFLICT(user_id) DO UPDATE SET audio=:v,changed_at=now()""",
            u=uid,
            v=s == "acepto audio",
        )
        return "Permiso de voz actualizado. Puedes revocarlo con REVOCO AUDIO."
    if s in YES and d.get("waiting") == "confirm":
        if any(not catalog(db, i["material"]) for i in d["items"]):
            save(db, uid, {})
            return review(db, uid)
        if d.get("edit"):
            rid = d["edit"]
            r = owned(db, uid, rid)
            if not r or r["status"] != "recibida":
                save(db, uid, {})
                return (
                    "La solicitud ya está en gestión. Pide contacto con coordinación."
                )
            i = next(item for item in d["items"] if item["material"] == r["material"])
            query(
                db,
                "UPDATE collection_requests SET quantity=:q,unit=:unit,preference=:p,address=:a WHERE id=:r",
                r=rid,
                q=i.get("quantity"),
                unit=i.get("unit"),
                p=d["preference"],
                a=d["address"],
            )
            for item in d["items"]:
                store_item(db, rid, item)
            history(db, rid, "corregida", uid)
            save(db, uid, {})
            return f"Aviso ECO-{rid} actualizado."
        record(db, "request_confirmed", d.get("attempt"))
        ids = create(db, uid, d)
        record(db, "request_registered", d.get("attempt"), count=len(ids.split(", ")))
        record(
            db, "routed_to_coordinator", d.get("attempt"), count=len(ids.split(", "))
        )
        save(db, uid, {})
        return f"Aviso recibido: {ids}. Coordinación revisará la solicitud. Aún no hay visita programada."
    if s in YES and d.get("waiting") == "cancel":
        r = owned(db, uid, d["id"])
        save(db, uid, {})
        if r and r["status"] in ("recibida", "asignada"):
            query(
                db,
                "UPDATE collection_requests SET status='cancelada' WHERE id=:id",
                id=r["id"],
            )
            history(db, r["id"], "cancelada", uid)
            return "Solicitud cancelada."
        return "El estado ya cambió. Solicita contacto con coordinación."
    if s in YES and d.get("last_asked") == ["eligibility"]:
        if d.get("review_requested"):
            return "La revisión ya está solicitada. Puedes decir «solo los demás» para continuar con el material reconocido."
        d["review_requested"] = True
        save(db, uid, d)
        return (
            review(db, uid, d.get("attempt"))
            + " Puedes decir «solo los demás» para continuar."
        )
    if s == "no" and d.get("waiting") in {"confirm", "cancel"}:
        if d.get("attempt"):
            record(db, "request_abandoned", d["attempt"], reason="declined")
        save(db, uid, {})
        return "Descarté el cambio pendiente."
    if re.search(UNSAFE + "|" + OTHER, s):
        record(
            db,
            "intent_identified",
            d.get("attempt"),
            intent="offtopic",
            scope="OUT_OF_SCOPE",
        )
        return LIMIT
    if d and s in YES:
        return progress(db, uid, d)
    result = understand(
        text,
        local_only=bool(d) or bool(ID.search(text)),
        observe=lambda event, **attributes: record(
            db, event, d.get("attempt"), **attributes
        ),
    )
    record(
        db,
        "intent_identified",
        d.get("attempt"),
        intent=result.intent,
        scope=result.scope,
    )
    intent = result.intent
    if result.scope == "OUT_OF_SCOPE":
        return LIMIT
    if result.scope == "UNCERTAIN" and not d:
        return CLARIFY
    if intent in (
        "event",
        "training",
        "points",
        "track",
        "recycling",
        "compost",
        "material",
        "human",
        "hello",
        "bye",
    ) and not (
        d
        and intent in ("material", "compost", "recycling")
        and not re.search(r"[?¿]|\b(como|sirve|puedo|antes|que hago)\b", s)
    ):
        if intent in ("training", "event"):
            reply = agenda(db, intent, text)
        elif intent == "points":
            val = one(
                db,
                "SELECT coalesce(sum(points),0) AS n FROM points_ledger JOIN collection_requests r ON r.id=request_id WHERE r.owner_id=:u",
                u=uid,
            )
            reply = f"Tienes {val['n']:g} puntos acreditados."
        elif intent == "track":
            r = owned(db, uid, text)
            reply = (
                f"ECO-{r['id']}: {r['status']}."
                if r
                else "No encuentro esa solicitud entre las tuyas."
            )
            if r and r["scheduled_at"]:
                reply += f" Programación: {r['scheduled_at'].astimezone(BOGOTA):%d/%m/%Y %H:%M}, {r['collector']}."
        elif intent in ("recycling", "compost", "material"):
            reply = education_reply(db, text, result)
        elif intent == "human":
            reply = review(db, uid, d.get("attempt"))
        else:
            reply = (
                "¡Hola! " + CLARIFY
                if intent == "hello"
                else "Gracias por participar en EcoConecta."
            )
        return reply + (" Tu borrador sigue pendiente." if d else "")
    if intent == "cancel":
        if d and not ID.search(text):
            if d.get("attempt"):
                record(db, "request_abandoned", d["attempt"], reason="cancelled_draft")
            save(db, uid, {})
            return "Descarté el borrador."
        r = owned(db, uid, text)
        if r and r["status"] in ("recibida", "asignada"):
            save(db, uid, {"waiting": "cancel", "id": str(r["id"])})
            return f"¿Confirmas cancelar ECO-{r['id']}?"
        return "No encuentro una solicitud propia disponible para cancelar."
    if intent == "modify" and not d:
        r = owned(db, uid, text)
        if not r or r["status"] != "recibida":
            return "Solo puedes corregir un aviso propio pendiente de revisión."
        d = {k: r[k] for k in ("preference", "address", "generator")}
        d.update(
            edit=str(r["id"]),
            items=[
                {
                    "material": item["material"],
                    "quantity": float(item["quantity"])
                    if item["quantity"] is not None
                    else None,
                    "unit": item["unit"],
                    "approximate": item["approximate"],
                    "description": item["description"],
                }
                for item in declared_items(db, r["id"])
            ],
            waiting="amount",
            index=0,
        )
        save(db, uid, d)
        if not amount(s):
            return "¿Qué cantidad quieres corregir? Puedes indicar bolsas, cajas u otra descripción."
    if d.get("waiting") == "cancel":
        return "Responde sí para cancelar o no para conservar tu solicitud."
    if (
        d.get("edit")
        and materials(s)
        and not set(materials(s)).issubset({i["material"] for i in d["items"]})
    ):
        return "Para cambiar de material, cancela el aviso y crea otro. Para salir de la corrección, responde no."
    if d or (intent == "collection" and result.scope == "IN_SCOPE"):
        return slots(db, uid, d, text, result)
    return CLARIFY if result.scope == "UNCERTAIN" or intent == "ambiguous" else LIMIT


def handle(db, uid, text):
    one(db, "SELECT id FROM users WHERE id=:u AND active FOR UPDATE", u=uid)
    before = one(db, "SELECT draft FROM conversations WHERE user_id=:u", u=uid)
    reply = _handle(db, uid, text)
    after = one(db, "SELECT draft FROM conversations WHERE user_id=:u", u=uid)
    attempt = next(
        (
            r["draft"]["attempt"]
            for r in (after, before)
            if r and r["draft"].get("attempt")
        ),
        None,
    )
    record(db, "bot_reply", attempt)
    return reply
